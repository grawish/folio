from pathlib import Path
import json,hashlib,subprocess,datetime,tarfile,io
sha=lambda b:hashlib.sha256(b).hexdigest()
commit='0bee2713cff6eed7872984f73229fec7ef722ff3'
original=lambda p:subprocess.check_output(['git','show',commit+':'+p])
identity=json.loads(Path('test-results/editor-lifecycle-keyboard-package-identity.json').read_text())
assert identity['applicationSource']==commit and identity['architecture']=='arm64' and len(identity['outputs'])==39
payload={'package-identity.json':Path('test-results/editor-lifecycle-keyboard-package-identity.json').read_bytes()}
checks={}
for name,root in [('workspace','workspace-0VjAON'),('recovery-writes','recovery-writes-xvnvr2'),('git','git-RgrcX8')]:
 p=Path('test-results')/root
 result=json.loads((p/'result.json').read_text()); assert result['passed'] and result['errors']==[]
 script='scripts/test-'+name+'.mjs'; assert Path(script).read_bytes()==original(script)
 checks[name]={'script':script,'scriptSha256':sha(original(script)),'result':result}
 for f in [p/'result.json',*p.glob('*.png'),*p.glob('layout-measurements.json')]:payload[name+'/'+f.name]=f.read_bytes()
 if name=='recovery-writes':
  assert result['sourceCommit']==commit and result['scriptSha256']==sha(original(script))
  for f,h in result['sourceHashes'].items():assert sha(original(f))==h
  assert result['appAsarSha256']==identity['asarSha256'] and result['runtimeManifestSha256']==identity['runtimeManifestSha256']
  assert result['nativeAdmission']=={'requests':100,'rejectedWhileHeld':96,'acknowledgedWhileHeld':0,'accepted':4,'newestRetrySaved':True}
  recovery=(p/'data/recovery.json').read_bytes();assert json.loads(recovery)['project']['files'][0]['content']=='\\documentclass{article}\n\\begin{document}\nRecovery snapshot 10.\n\\end{document}'
  payload[name+'/final-recovery.json']=recovery
 if name=='workspace':assert any('Chat/Code/Git' in item for item in result['keyboardChecks'])
 if name=='git':
  repo=Path(result['fixtureRoot'])/'project'
  head=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip();assert head==result['commit']['hash']
  content=subprocess.check_output(['git','-C',str(repo),'show','HEAD:main.tex']);assert content==(repo/'main.tex').read_bytes()
  assert content.endswith(b'% tracked change\n') and result['sourceMatches'] and result['uiInitializeStageCommit'] and result['codeViewRestored']
  payload[name+'/actual-committed-main.tex']=content
  checks[name]['actualCommitAndSourceIndependentlyChecked']=True
physical=Path('artifacts/license-materials/mac-app/2bcdb04373ae82fbff35aafc922de318f77fdb9a4a6767d89c1a1902e18039a1')
js=Path('artifacts/license-materials/javascript/ab04c3f6d6f1dda458605e2e2daa1efc9769921381a028cfddbb6f45eaa193e1')
physical_summary=json.loads((physical/'summary.json').read_text());js_summary=json.loads((js/'summary.json').read_text());publisher=json.loads((js/'publisher-sources.json').read_text())
assert physical_summary['appAsarSha256']==js_summary['appAsarSha256']==identity['asarSha256']
assert physical_summary['runtimeFilesVerified']==3982 and physical_summary['regularFiles']+physical_summary['directories']+physical_summary['symlinks']==5879
assert publisher['passed'] and publisher['npmInputFilesMatched']==259 and publisher['embeddedOriginalSourcesMatched']==45 and publisher['originalArchivesChecked']==38
for root,files in [(physical,['summary.json']), (js,['summary.json','publisher-sources.json'])]:
 for f in files:payload[('physical/' if root==physical else 'javascript/')+f]=(root/f).read_bytes()
for suffix in ['workspace','recovery','git','package','physical-inventory','javascript-inventory','publisher-verification','publisher-verified-cache']:
 f=Path('test-results/editor-lifecycle-keyboard-'+suffix+'.log');payload['logs/'+f.name]=f.read_bytes()
payload['verify-editor-keyboard-local.py']=Path(__file__).read_bytes()
archive=Path('docs/performance/editor-keyboard-local-traces.tar.gz')
with tarfile.open(archive,'w:gz') as t:
 for name,data in sorted(payload.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as t:assert {m.name:t.extractfile(m).read() for m in t.getmembers()}==payload
out={'verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True,'source':commit,'package':identity,'nativeChecks':checks,'physicalInventory':physical_summary,'javascriptSummary':js_summary,'publisherSourceVerification':publisher,'archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'files':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(payload.items())]},'scope':'Three affected native suites on a separate unsigned local Apple silicon package. Workspace keyboard coverage includes all three tabs and modal focus. Recovery retains the exact four accepted/96 rejected capacity assertion. Actual Git commit/source and final recovery source independently read. All 39 compiled outputs match the package; all 3,982 runtime files are inventoried. Publisher verification initially used an unavailable/invalid default archive cache; the retained verified cache passes all 38 archives. Full hosted qualification is still running. No physical VoiceOver/IME, signing, full binary redistribution or resource-budget claim.'}
Path('docs/releases/editor-keyboard-local-verification.json').write_text(json.dumps(out,indent=2)+'\n')
print('Verified three native suites, actual saved source/commit, package identities and retained archive:',len(payload),'files.')
